package com.example.nextrack.utils

import android.app.Dialog
import android.widget.LinearLayout


fun Dialog.setupDialog(layoutRestId: Int){
    setContentView(layoutRestId)
    window!!.setLayout(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
    setCancelable(false)
}